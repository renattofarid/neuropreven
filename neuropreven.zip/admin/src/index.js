import { MySidebar } from "/admin/src/components/MySidebar.js";
import { MyNavbar } from "/admin/src/components/MyNavbar.js";

customElements.define("my-sidebar", MySidebar);
customElements.define("my-navbar", MyNavbar);
